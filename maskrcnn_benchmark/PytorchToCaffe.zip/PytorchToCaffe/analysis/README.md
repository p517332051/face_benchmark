# Blob
the input Blob must have the first dimension for batch_size
for image (batch_size,w,h,c)